"""
cli/run_case.py

Reproducible case runner for the radar pipeline.

Purpose
-------
Run one validated radar "case" end-to-end and produce a stable run directory
containing machine-readable metrics and a human-readable HTML report.

This CLI is the primary boundary of the pipeline:
- schema validation and unit normalization happen at load time
- execution is deterministic given (config, seed)
- outputs are written to a new run directory with a stable layout

Engines
-------
- model_based  : fast closed-form/statistical performance engine
- monte_carlo  : empirical validation engine (Pfa/FAR-style experiments)
- signal_level : selective RD-map/IQ-style spot validation

Outputs
-------
<out>/<run_name>/
  - case_manifest.json
  - metrics.json
  - report.html                (if --report)
  - plots/                     (if --report and plots are derivable)
      - snr_vs_range.png        (model_based when available)
      - pd_vs_range.png         (model_based when available)
      - far_summary.png         (optional text plot, when meaningful)
  - logs/                       (reserved)

Design constraints
------------------
- No absolute paths in the HTML output.
- Deterministic formatting where possible (sorted keys, stable rounding).
- The report is single-file self-contained: images are embedded as base64.

Usage
-----
Run a case:
    python -m cli.run_case --case configs/cases/demo_pd_noise.yaml --engine model_based --seed 123

Generate report:
    python -m cli.run_case --case configs/cases/demo_pd_noise.yaml --engine model_based --seed 123 --report

Exit codes
----------
0 : success
2 : config/schema validation error
3 : unexpected config loading error
4 : manifest write failure
5 : engine execution failure
6 : metrics write failure
7 : report generation failure
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Optional
import datetime as _dt

from core.config.loaders import load_case, LoadOptions, ConfigError
from core.config.manifest import write_case_manifest

# plots + report renderer are optional unless --report is used
from reports.plots import plot_xy
from reports.html_case_report import render_case_report_html, read_optional_json


# ----------------------------
# CLI
# ----------------------------

def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="run_case",
        description="Run a single radar performance/simulation case (reproducible).",
    )

    parser.add_argument("--case", required=True, help="Path to case YAML/JSON.")
    parser.add_argument("--out", default="results/cases", help="Base output dir (default: results/cases).")
    parser.add_argument("--name", default=None, help="Optional run name. Default: <case_stem>__<timestamp_utc>.")
    parser.add_argument("--seed", type=int, default=None, help="Optional RNG seed.")
    parser.add_argument("--schema-dir", default="configs/schemas", help="Schema folder (default: configs/schemas).")
    parser.add_argument("--schema", default="case.schema.json", help="Schema filename (default: case.schema.json).")
    parser.add_argument(
        "--engine",
        default="auto",
        choices=["auto", "model_based", "monte_carlo", "signal_level"],
        help="Engine selection (default: auto).",
    )

    parser.add_argument("--strict", action="store_true", help="Enable strict schema validation (default).")
    parser.add_argument("--non-strict", dest="strict", action="store_false", help="Disable strict validation.")
    parser.set_defaults(strict=True)

    parser.add_argument(
        "--report",
        action="store_true",
        help="Generate a self-contained HTML report.html with embedded plots.",
    )

    return parser.parse_args()


def _default_run_name(case_path: Path) -> str:
    ts = _dt.datetime.now(tz=_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{case_path.stem}__{ts}"


def _write_json(path: Path, obj: Dict[str, Any]) -> None:
    text = json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False)
    path.write_text(text + "\n", encoding="utf-8")


# ----------------------------
# Engine dispatch
# ----------------------------

def _auto_select_engine(cfg: Dict[str, Any]) -> str:
    mc = cfg.get("monte_carlo", None)
    if isinstance(mc, dict):
        return "monte_carlo"
    return "model_based"


def _run_engine(engine: str, cfg: Dict[str, Any], seed: Optional[int]) -> Dict[str, Any]:
    engine_n = str(engine).lower().strip()
    if engine_n == "auto":
        engine_n = _auto_select_engine(cfg)

    if engine_n == "model_based":
        from core.simulation.model_based import run_model_based_case
        return run_model_based_case(cfg=cfg, seed=seed)

    if engine_n == "monte_carlo":
        from core.simulation.monte_carlo import run_pfa_monte_carlo
        return run_pfa_monte_carlo(cfg=cfg, seed=seed)

    if engine_n == "signal_level":
        from core.simulation.signal_level import run_signal_level_case
        return run_signal_level_case(cfg=cfg, seed=seed)

    raise ValueError(f"Unknown engine: {engine}")


# ----------------------------
# Report plumbing
# ----------------------------

def _maybe_generate_case_plots(*, metrics: Dict[str, Any], plots_dir: Path) -> Dict[str, bytes]:
    """
    Generate a minimal, readable plot set from metrics when the required fields exist.

    Notes
    -----
    - Only generates plots when data exists (no guessing).
    - Writes PNG files to plots_dir and returns {filename: bytes} for HTML embedding.
    """
    plots_dir.mkdir(parents=True, exist_ok=True)
    embedded: Dict[str, bytes] = {}

    eng = metrics.get("engine")

    # model_based: snr_db vs ranges_m, pd vs ranges_m (if available)
    if eng == "model_based":
        ranges = metrics.get("ranges_m")
        snr_db = metrics.get("snr_db")
        if isinstance(ranges, list) and isinstance(snr_db, list) and len(ranges) == len(snr_db) and len(ranges) > 1:
            p = plots_dir / "snr_vs_range.png"
            plot_xy(
                x=ranges,
                y=snr_db,
                xlabel="Range [m]",
                ylabel="SNR [dB]",
                title="SNR vs Range",
                out_path=p,
                ylog=False,
            )
            embedded[p.name] = p.read_bytes()

        det = metrics.get("detection")
        if isinstance(det, dict):
            pd = det.get("pd")
            if isinstance(ranges, list) and isinstance(pd, list) and len(ranges) == len(pd) and len(ranges) > 1:
                p = plots_dir / "pd_vs_range.png"
                plot_xy(
                    x=ranges,
                    y=pd,
                    xlabel="Range [m]",
                    ylabel="Pd",
                    title="Pd vs Range",
                    out_path=p,
                    ylog=False,
                )
                embedded[p.name] = p.read_bytes()

    # signal_level: v1 doesn’t store the RD map; only stats exist -> no plot unless you add map export later.
    # monte_carlo: also mostly scalar outputs -> report shows tables; plots can be added when you store series.

    return embedded


def _write_html_report(*, out_dir: Path, metrics: Dict[str, Any]) -> None:
    manifest = read_optional_json(out_dir / "case_manifest.json")
    plots = _maybe_generate_case_plots(metrics=metrics, plots_dir=(out_dir / "plots"))

    html = render_case_report_html(
        metrics=metrics,
        manifest=manifest,
        plots=plots,
        title=f"Radar Case Report — {out_dir.name}",
    )
    (out_dir / "report.html").write_text(html, encoding="utf-8")


# ----------------------------
# Main
# ----------------------------

def main() -> int:
    args = _parse_args()

    case_path = Path(args.case)
    out_base = Path(args.out)

    run_name = args.name or _default_run_name(case_path)
    out_dir = (out_base / run_name).resolve()

    # Layout
    (out_dir / "logs").mkdir(parents=True, exist_ok=True)
    (out_dir / "plots").mkdir(parents=True, exist_ok=True)

    # Load + validate + normalize config.
    try:
        cfg = load_case(
            case_path,
            schema_dir=args.schema_dir,
            schema_name=args.schema,
            options=LoadOptions(strict=args.strict, resolve_paths=True, normalize_units=True),
        )
    except ConfigError as exc:
        print(f"[ERROR] Config load/validation failed: {exc}")
        return 2
    except Exception as exc:
        print(f"[ERROR] Unexpected error while loading config: {exc}")
        return 3

    # Resolve engine (auto-selection depends on loaded cfg).
    selected_engine = args.engine
    if str(selected_engine).lower().strip() == "auto":
        selected_engine = _auto_select_engine(cfg)

    # Manifest for reproducibility.
    extras = {
        "cli_args": vars(args),
        # Store a stable relative path, not an absolute machine path.
        "output_dir": str(Path(args.out) / run_name),
        "engine_requested": args.engine,
        "engine_selected": selected_engine,
    }
    try:
        write_case_manifest(
            cfg,
            output_dir=out_dir,
            seed=args.seed,
            extras=extras,
            project_root=Path.cwd(),
            engine_package="radar_pipeline",
        )
    except Exception as exc:
        print(f"[ERROR] Failed to write case manifest: {exc}")
        return 4

    # Run engine and write metrics.
    try:
        metrics = _run_engine(args.engine, cfg, args.seed)
    except Exception as exc:
        print(f"[ERROR] Engine execution failed: {exc}")
        return 5

    try:
        _write_json(out_dir / "metrics.json", metrics)
    except Exception as exc:
        print(f"[ERROR] Failed to write metrics.json: {exc}")
        return 6

    # Optional: HTML report (self-contained)
    if args.report:
        try:
            _write_html_report(out_dir=out_dir, metrics=metrics)
        except Exception as exc:
            print(f"[ERROR] Failed to write report.html: {exc}")
            return 7

    print(f"[OK] Case complete: {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())