"""
cli/run_sweep.py

Deterministic grid sweep runner for the radar pipeline.

What this script does
---------------------
- Loads a validated base performance case (YAML/JSON) using the same boundary rules as run_case:
  schema validation (strict), path resolution, and unit normalization.
- Loads a sweep specification (YAML/JSON) describing a deterministic parameter grid.
- Executes the sweep by materializing each grid point config and running a selected engine:
    - model_based  : closed-form / statistical performance engine (fast)
    - monte_carlo  : empirical validation engine (slower)
    - signal_level : selective RD-map / IQ-style spot validation (selective)
- Writes a single sweep JSON artifact with all points and their metrics outputs.
- Optionally generates a human-facing report:
    - report.json (KPIs + Pareto metadata)
    - report.html (rendered explanation + plots, produced by reports.generators)

Inputs (CLI)
------------
Required:
- --case   : base case YAML/JSON (performance case)
- --sweep  : sweep specification YAML/JSON (grid definition)
- --out    : output path. Two modes:
    1) If it ends with ".json", it is treated as the sweep JSON file path.
    2) Otherwise, it is treated as an output directory, and the file "sweep.json" is written inside it.

Optional:
- --engine : {model_based, monte_carlo, signal_level} (default: model_based)
- --seed   : integer seed used for deterministic sweeps (default: 123)
- --name   : sweep run name (used only when --out is a directory; default: sweep file stem + timestamp UTC)
- --report : generate report artifacts in "<out_dir>/report/" (report.json + report.html)
- --objectives : Pareto objectives as a comma-separated list:
      "far.per_second:min,snr_db@10000:max"
  (Only used when --report is set.)

Sweep JSON output format
------------------------
The sweep artifact is written as:

{
  "meta": {
    "case_path": "...",
    "sweep_path": "...",
    "engine": "model_based",
    "seed": 123,
    "timestamp_utc": "...",
  },
  "n_points": <int>,
  "results": [
    {
      "sweep_point": {"radar.prf_hz": 1000, ...},
      "metrics": {...}   # engine metrics dict (same shape as metrics.json from run_case)
    },
    ...
  ]
}

Output layout (directory mode)
------------------------------
<out_dir>/
  sweep.json
  report/
    report.json
    report.html
    plots/
      *.png

Design constraints
------------------
- Deterministic: same inputs + seed -> same sweep outputs.
- Conservative: no plotting or heuristics inside the sweep runner; reporting is delegated to reports.generators.
- Errors are surfaced with actionable messages and non-zero exit codes.

Dependencies
------------
- Standard library only in this CLI file.
- Pipeline modules:
  - core.config.loaders
  - sweeps.grid
  - core.simulation.*
  - reports.generators (only if --report)
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple


from core.config.loaders import load_case, LoadOptions, ConfigError
from sweeps.grid import run_grid_sweep


# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="run_sweep",
        description="Run a deterministic grid sweep over a radar case.",
    )

    parser.add_argument("--case", required=True, help="Base case YAML/JSON file (performance case).")
    parser.add_argument("--sweep", required=True, help="Sweep specification YAML/JSON file (grid definition).")

    parser.add_argument(
        "--out",
        required=True,
        help=(
            "Output path. If it ends with .json, it is treated as the sweep JSON file path. "
            "Otherwise it is treated as an output directory and 'sweep.json' is written inside."
        ),
    )

    parser.add_argument(
        "--engine",
        default="model_based",
        choices=["model_based", "monte_carlo", "signal_level"],
        help="Simulation engine to run for each sweep point (default: model_based).",
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=123,
        help="Seed used to make the sweep deterministic (default: 123).",
    )

    parser.add_argument(
        "--name",
        default=None,
        help=(
            "Optional run name (directory mode only). "
            "If omitted, uses <sweep_stem>__<timestamp_utc>."
        ),
    )

    parser.add_argument(
        "--report",
        action="store_true",
        help=(
            "Generate a report in '<out_dir>/report/' (report.json + report.html + plots/). "
            "Requires reports.generators."
        ),
    )

    parser.add_argument(
        "--objectives",
        default=None,
        help=(
            "Optional Pareto objectives for reporting, e.g. "
            "'far.per_second:min,snr_db@10000:max'. Only used when --report is set."
        ),
    )

    return parser.parse_args()


def _default_run_name(sweep_path: Path) -> str:
    ts = _dt.datetime.now(tz=_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{sweep_path.stem}__{ts}"


# ---------------------------------------------------------------------
# Objectives parsing (reporting)
# ---------------------------------------------------------------------


def _parse_objectives(text: Optional[str]) -> Optional[Dict[str, str]]:
    """
    Parse Pareto objectives from a CLI string.

    Expected format:
      "far.per_second:min,snr_db@10000:max"

    Returns
    -------
    dict[str, str] | None
        Keys are objective names, values are "min" or "max".
    """
    if text is None:
        return None

    raw = str(text).strip()
    if raw == "":
        return None

    out: Dict[str, str] = {}
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    for part in parts:
        if ":" not in part:
            raise ValueError(f"Invalid objective '{part}': expected '<key>:<min|max>'")
        k, d = part.split(":", 1)
        key = k.strip()
        direction = d.strip().lower()
        if key == "":
            raise ValueError(f"Invalid objective '{part}': empty key")
        if direction not in {"min", "max"}:
            raise ValueError(f"Invalid objective '{part}': direction must be 'min' or 'max'")
        out[key] = direction

    return out or None


# ---------------------------------------------------------------------
# Engine runner
# ---------------------------------------------------------------------


def _make_runner(engine: str, seed: int) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """
    Create a per-point runner callable for run_grid_sweep.

    The runner signature is runner(cfg) -> metrics dict.
    """
    engine_n = str(engine).lower().strip()

    if engine_n == "model_based":
        from core.simulation.model_based import run_model_based_case  # local import by design

        def _runner(cfg: Dict[str, Any]) -> Dict[str, Any]:
            return run_model_based_case(cfg=cfg, seed=int(seed))

        return _runner

    if engine_n == "monte_carlo":
        from core.simulation.monte_carlo import run_pfa_monte_carlo  # local import by design

        def _runner(cfg: Dict[str, Any]) -> Dict[str, Any]:
            return run_pfa_monte_carlo(cfg=cfg, seed=int(seed))

        return _runner

    if engine_n == "signal_level":
        from core.simulation.signal_level import run_signal_level_case  # local import by design

        def _runner(cfg: Dict[str, Any]) -> Dict[str, Any]:
            return run_signal_level_case(cfg=cfg, seed=int(seed))

        return _runner

    raise ValueError(f"Unknown engine: {engine}")


# ---------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------


def _resolve_out(args_out: str, sweep_path: Path, name: Optional[str]) -> Tuple[Path, Path]:
    """
    Resolve output paths.

    Returns
    -------
    out_dir : Path
        Directory that will contain sweep.json and optional report/ artifacts.
    sweep_json_path : Path
        Path to the sweep JSON file to write.
    """
    out = Path(args_out)

    # File mode: explicit .json path
    if out.suffix.lower() == ".json":
        out_dir = out.parent
        sweep_json_path = out
        return out_dir, sweep_json_path

    # Directory mode: create a run folder inside `out`
    run_name = name or _default_run_name(sweep_path)
    out_dir = (out / run_name).resolve()
    sweep_json_path = out_dir / "sweep.json"
    return out_dir, sweep_json_path


def _write_json(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------


def main() -> int:
    args = _parse_args()

    case_path = Path(args.case)
    sweep_path = Path(args.sweep)
    out_dir, sweep_json_path = _resolve_out(args.out, sweep_path=sweep_path, name=args.name)

    try:
        objectives = _parse_objectives(args.objectives) if args.report else None
    except Exception as exc:
        print(f"[ERROR] Invalid --objectives: {exc}")
        return 2

    # Load base case with strict validation + unit normalization (performance boundary).
    try:
        base_cfg = load_case(
            case_path,
            options=LoadOptions(strict=True, resolve_paths=True, normalize_units=True),
        )
    except ConfigError as exc:
        print(f"[ERROR] Failed to load/validate base case: {exc}")
        return 3
    except Exception as exc:
        print(f"[ERROR] Unexpected error while loading base case: {exc}")
        return 4

    # Load sweep spec with relaxed validation (it is not a performance case).
    try:
        sweep_spec = load_case(
            sweep_path,
            options=LoadOptions(strict=False, resolve_paths=True, normalize_units=False),
        )
    except Exception as exc:
        print(f"[ERROR] Failed to load sweep spec: {exc}")
        return 5

    # Run sweep.
    try:
        runner = _make_runner(engine=args.engine, seed=int(args.seed))
        results = run_grid_sweep(base_cfg=base_cfg, sweep_spec=sweep_spec, runner=runner)
    except Exception as exc:
        print(f"[ERROR] Sweep execution failed: {exc}")
        return 6

    # Write sweep artifact.
    meta = {
        "case_path": str(case_path),
        "sweep_path": str(sweep_path),
        "engine": str(args.engine),
        "seed": int(args.seed),
        "timestamp_utc": _dt.datetime.now(tz=_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "out_dir": str(out_dir),
    }
    sweep_obj: Dict[str, Any] = {
        "meta": meta,
        "n_points": int(len(results)),
        "results": results,
    }

    try:
        out_dir.mkdir(parents=True, exist_ok=True)
        _write_json(sweep_json_path, sweep_obj)
    except Exception as exc:
        print(f"[ERROR] Failed to write sweep JSON: {exc}")
        return 7

    # Optional: generate report artifacts.
    if bool(args.report):
        try:
            from reports.generators import generate_sweep_report  # local import by design
        except Exception as exc:
            print(f"[ERROR] Reporting requested but reports.generators import failed: {exc}")
            return 8

        report_dir = out_dir / "report"
        try:
            generate_sweep_report(
                sweep_json_path=sweep_json_path,
                out_dir=report_dir,
                objectives=objectives,
                write_html=True,
            )
        except TypeError:
            # Backward compatibility if generate_sweep_report does not yet accept write_html
            try:
                generate_sweep_report(
                    sweep_json_path=sweep_json_path,
                    out_dir=report_dir,
                    objectives=objectives,
                )
            except Exception as exc:
                print(f"[ERROR] Report generation failed: {exc}")
                return 9
        except Exception as exc:
            print(f"[ERROR] Report generation failed: {exc}")
            return 9

        print(f"[OK] Report complete: {report_dir / 'report.html'}")

    print(f"[OK] Sweep complete: {sweep_json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())