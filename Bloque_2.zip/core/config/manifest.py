"""
core/config/manifest.py

Case manifest generation for reproducibility, WITHOUT leaking absolute paths.

Goals
-----
- Keep the run reproducible (config, seed, git hash, package version, CLI extras).
- Avoid leaking machine-specific absolute paths (e.g. /Users/.../venv/bin/python).
- Allow reports to embed manifest safely.

Policy
------
- Any path under project_root is stored as "${PROJECT_ROOT}/<relative>".
- Any path outside project_root is reduced to a safe token:
    "<ABSOLUTE_PATH_REDACTED>:<basename>"
- user/hostname are stored as-is (can be redacted later), but you can also opt-out.

This file is intentionally deterministic: stable key ordering and formatting.
"""

from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional


class ManifestError(RuntimeError):
    """Raised when manifest generation or writing fails."""


def _safe_path_str(value: str, project_root: Optional[Path]) -> str:
    """
    Sanitize a path-like string to avoid leaking absolute machine paths.

    - If it is inside project_root -> "${PROJECT_ROOT}/relpath"
    - Else if it looks absolute -> "<ABSOLUTE_PATH_REDACTED>:basename"
    - Else -> unchanged
    """
    if not isinstance(value, str) or not value:
        return value

    # Quick absolute checks (POSIX + Windows-ish)
    is_abs = value.startswith("/") or value.startswith("\\") or (len(value) >= 3 and value[1:3] == ":\\")

    if project_root is not None:
        try:
            p = Path(value)
            if p.is_absolute():
                try:
                    rel = p.resolve().relative_to(project_root.resolve())
                    return "${PROJECT_ROOT}/" + rel.as_posix()
                except Exception:
                    pass
        except Exception:
            pass

    if is_abs:
        base = Path(value).name or "path"
        return f"<ABSOLUTE_PATH_REDACTED>:{base}"

    return value


def _walk_sanitize(obj: Any, project_root: Optional[Path]) -> Any:
    """Recursively sanitize strings that may contain absolute paths."""
    if isinstance(obj, dict):
        out: Dict[str, Any] = {}
        for k in sorted(obj.keys()):
            out[k] = _walk_sanitize(obj[k], project_root)
        return out
    if isinstance(obj, list):
        return [_walk_sanitize(v, project_root) for v in obj]
    if isinstance(obj, str):
        return _safe_path_str(obj, project_root)
    return obj


def _git_info(project_root: Path) -> Dict[str, Any]:
    """
    Best-effort git info. Must not throw; if unavailable, return minimal info.
    """
    info: Dict[str, Any] = {"hash": "", "dirty": None}
    try:
        h = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=str(project_root), text=True).strip()
        info["hash"] = h
    except Exception:
        return info

    try:
        s = subprocess.check_output(["git", "status", "--porcelain"], cwd=str(project_root), text=True)
        info["dirty"] = bool(s.strip())
    except Exception:
        info["dirty"] = None
    return info


def build_case_manifest(
    cfg: Dict[str, Any],
    *,
    seed: Optional[int],
    extras: Optional[Dict[str, Any]],
    project_root: Optional[Path],
    engine_package: str = "radar_pipeline",
    include_identity: bool = True,
) -> Dict[str, Any]:
    """
    Build an in-memory case manifest dict.

    Parameters
    ----------
    cfg:
        Fully loaded + normalized case config dict.
    seed:
        RNG seed used by the engine.
    extras:
        Arbitrary extra metadata (CLI args, engine selected, etc).
    project_root:
        Repo root path; used to sanitize paths deterministically.
    engine_package:
        Name used for packaging/version metadata.
    include_identity:
        If False, omit user/hostname entirely.

    Returns
    -------
    dict:
        JSON-serializable manifest.
    """
    pr = project_root.resolve() if isinstance(project_root, Path) else None

    env: Dict[str, Any] = {
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        # These are the usual offenders for leaking paths:
        "executable": sys.executable,
        "cwd": str(Path.cwd()),
    }
    if include_identity:
        env["user"] = os.environ.get("USER") or os.environ.get("USERNAME") or ""
        env["hostname"] = platform.node()

    manifest: Dict[str, Any] = {
        "engine_package": engine_package,
        "seed": seed,
        "case": cfg,  # already normalized by loaders
        "git": _git_info(pr) if pr is not None else {"hash": "", "dirty": None},
        "environment": env,
        "extras": extras or {},
    }

    # Sanitize everything path-like in one pass
    manifest = _walk_sanitize(manifest, pr)
    return manifest


def _write_json_deterministic(path: Path, obj: Dict[str, Any]) -> None:
    text = json.dumps(obj, indent=2, ensure_ascii=False)
    path.write_text(text + "\n", encoding="utf-8")


def write_case_manifest(
    cfg: Dict[str, Any],
    *,
    output_dir: Path,
    seed: Optional[int],
    extras: Optional[Dict[str, Any]] = None,
    project_root: Optional[Path] = None,
    engine_package: str = "radar_pipeline",
    include_identity: bool = True,
    filename: str = "case_manifest.json",
) -> Dict[str, Any]:
    """
    Build and write a case manifest JSON file to output_dir.

    Returns the manifest dict.
    """
    try:
        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / filename

        manifest = build_case_manifest(
            cfg,
            seed=seed,
            extras=extras,
            project_root=project_root,
            engine_package=engine_package,
            include_identity=include_identity,
        )

        _write_json_deterministic(out_path, manifest)
        return manifest
    except Exception as exc:
        raise ManifestError(f"Failed to write manifest JSON to {output_dir}: {exc}") from exc